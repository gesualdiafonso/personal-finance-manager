# OD-8 — Compras com cartão, saldos e faturas

**Estado:** decidida pelo responsável em 2026-11-24. **Implementada em parte no Step 04 (D4-08):** débito e pré-pago descontam da conta na data da compra; as compras com crédito ficam como "comprometido" sem mexer na conta. **Por implementar** (step próprio): faturas, cuotas, pagamento de fatura, crédito disponível e devoluções.

## Decidido

| Tema | Decisão |
| --- | --- |
| Cartão de débito | A compra é uma despesa da conta de pagamento **na data da compra**, como uma despesa normal. Sem fatura nem "comprometido". |
| Cartão pré-pago | Igual ao débito: desconta da conta associada na data da compra. O saldo próprio do cartão não é modelado. |
| Cartão de crédito | **Modelo por fatura**: as compras acumulam-se na fatura aberta até ao dia de fecho (compra depois do fecho → fatura seguinte); ao fechar, a fatura fica com total e data de vencimento; o **pagamento** da fatura é um movimento da conta para o cartão e é o único que desconta da conta, marcando a fatura como paga. |
| Relatórios | A despesa conta na data da compra, por categoria; o pagamento da fatura não é despesa (sem dupla contagem). |
| Crédito disponível | Passa a existir: limite − o que está por pagar. O detalhe do cartão passa a ser por fatura (aberta, fechada, paga), como no Design System. |
| Moeda | Cada fatura na sua moeda, sem conversão (D2-02). |
| Cuotas | Implementadas **junto com as faturas**: uma compra em N prestações reparte-se por N faturas consecutivas. |
| Pagamento parcial / mínimo | Permitido: o que não se paga passa para a fatura seguinte. Os **juros registam-se à mão** (não são calculados pela app). |
| Devoluções | Abatem na fatura aberta. |

## Impacto quando for implementada

- Substitui D2-11 nas regras de saldo (`src/domain/rules/balances.ts`) e nos indicadores de cartões.
- Novo modelo de fatura (schema 2.x, aditivo ou não — a definir no plano do step) e regras de fecho/vencimento já existentes (`src/domain/rules/cards.ts`).
- Os dados de exemplo e os testes de saldo mudam (o cartão de débito passa a descontar da conta).
